package com.example.crud.dao;

import com.example.crud.entity.Employee;
import com.example.crud.entity.Student;

import java.util.List;

public interface EmployeeDAO {

    void save(Employee theEmployee);

    Employee findbyID(Integer eid);

    List<Employee> findAll();

    void update (Employee theEmployee);

    void delete(Integer id);

    int deleteall();
}
