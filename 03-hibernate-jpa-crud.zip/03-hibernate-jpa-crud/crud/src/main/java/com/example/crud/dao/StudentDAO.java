package com.example.crud.dao;

import com.example.crud.entity.Student;
import jakarta.persistence.criteria.CriteriaBuilder;

import java.util.List;

public interface StudentDAO {


    void save (Student theStudent);

    Student findbyID(Integer id);

    List<Student> findAll();

    List<Student> findbyfirstname(String thefirstName);

    void update(Student theStudent);


    void delete(Integer id);

    int deleteAll();
}
