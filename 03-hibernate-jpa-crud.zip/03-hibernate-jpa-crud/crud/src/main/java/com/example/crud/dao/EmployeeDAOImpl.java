package com.example.crud.dao;

import com.example.crud.entity.Employee;
import com.example.crud.entity.Student;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.lang.model.element.TypeElement;
import java.util.List;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO{

    private final EntityManager entityManager;

    public EmployeeDAOImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    @Transactional
    public void save(Employee theEmployee) {
        entityManager.persist(theEmployee);

    }

    @Override
    public Employee findbyID(Integer eid) {
      return  entityManager.find(Employee.class,eid);
    }

    @Override
    public List<Employee> findAll() {
        TypedQuery<Employee> theQuery = entityManager.createQuery("FROM Employee order by name desc",Employee.class);
        return theQuery.getResultList();

    }

    @Override
    @Transactional
    public void update(Employee theEmployee) {
        entityManager.merge(theEmployee);

    }

    @Override
    @Transactional
    public void delete(Integer id) {
        Employee theEmployee = entityManager.find(Employee.class,id);
        entityManager.remove(theEmployee);
    }

    @Override
    @Transactional
    public int deleteall() {
        int num = entityManager.createQuery("DELETE FROM Employee").executeUpdate();
        return num;
    }


}
