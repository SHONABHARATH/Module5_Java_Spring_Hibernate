package com.example.crud.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "Employeee")
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "eid")
    private int eid;

    @Column(name = "name")
    private String name;

    @Column(name = "mail")
    private String mail;

    public Employee()
    {

    }
    public Employee(String name, String mail) {
        this.name = name;
        this.mail = mail;
    }

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @Override
    public String toString() {
        return "Employee{" +
                "eid=" + eid +
                ", name='" + name + '\'' +
                ", mail='" + mail + '\'' +
                '}';
    }


}
