package com.example.crud.dao;

import com.example.crud.entity.Student;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public class StudentDAOImpl implements StudentDAO{

    public EntityManager entityManager;

    public StudentDAOImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public List<Student> findAll() {
        TypedQuery<Student> query = entityManager.createQuery("from Student",Student.class);
        List<Student> temp = query.getResultList();
        return(temp);
    }

    @Override
    public Student findbyId(int id) {
        Student temp = entityManager.find(Student.class,id);
        return temp;
    }

    @Override
    public Student save(Student theStudent) {

        Student temp = entityManager.merge(theStudent);
        return temp;
    }

    @Override
    public void remove(int id) {
        Student temp = entityManager.find(Student.class,id);
        entityManager.remove(id);
    }
}
