package com.example.crud.rest;

import com.example.crud.dao.FlowerDAO;
import com.example.crud.entity.Flower;
import com.example.crud.service.FlowerService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/flowers")

public class FlowerController {

    public FlowerService flowerService;

    public FlowerController(FlowerService myflowerservice)
    {
        flowerService = myflowerservice;
    }

    @GetMapping("/all")
    public List<Flower> findAll()
    {
        return flowerService.findAll();
    }

    @GetMapping("/all/{id}")
    public Flower findbyid(@PathVariable int id)
    {
        Flower flower = flowerService.findbyId(id);
        return flower;
    }

    @PostMapping("/add")
    public Flower add(@RequestBody Flower theflower)
    {
        Flower flower = flowerService.save(theflower);
        return flower;
    }

    @PutMapping("/update")
    public Flower update(@RequestBody Flower theflower)
    {
        Flower flower = flowerService.save(theflower);
        return flower;
    }

    @DeleteMapping("/delete/{id}")
    public String remove(@PathVariable int id)
    {
        flowerService.remove(id);
        return "id deleted: " + id;
    }



}
