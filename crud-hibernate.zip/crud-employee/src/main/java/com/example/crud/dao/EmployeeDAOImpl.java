package com.example.crud.dao;

import com.example.crud.entity.Employee;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
@Repository
public class EmployeeDAOImpl implements EmployeeDAO{

    public EntityManager entityManager;

    @Autowired
    public EmployeeDAOImpl(EntityManager theentitymanager)
    {
        entityManager = theentitymanager;
    }

    @Override
    public List<Employee> findAll() {
        TypedQuery<Employee> thequery = entityManager.createQuery("from Employee", Employee.class);
        List<Employee> employees = thequery.getResultList();
        return employees;
    }

    @Override
    public Employee findbyID(int theID) {
        Employee theEmployee = entityManager.find(Employee.class,theID);
        return theEmployee;
    }

    @Override
    public Employee save(Employee theEmployee) {
        Employee dbEmployee = entityManager.merge(theEmployee);
        return dbEmployee;
    }

    @Override
    public void remove(int theID) {
        Employee theEmployee = entityManager.find(Employee.class,theID);
        entityManager.remove(theEmployee);
    }
}
