package com.example.crud.dao;

import com.example.crud.entity.Police;

import java.util.List;

public interface PoliceDAO {

    List<Police> findAll();

    Police findbyid(int id);

    Police save(Police police);

    void remove(int id);

}
