package com.example.crud.service;

import com.example.crud.entity.Flower;

import java.util.List;

public interface FlowerService {
    List<Flower> findAll();
    Flower findbyId(int id);
    Flower save(Flower theflower);
    void remove(int id);
}
