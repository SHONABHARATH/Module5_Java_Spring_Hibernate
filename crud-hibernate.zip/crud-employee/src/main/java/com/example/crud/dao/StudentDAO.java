package com.example.crud.dao;

import com.example.crud.entity.Student;

import java.util.List;

public interface StudentDAO {

    List<Student> findAll();

    Student findbyId(int id);

    Student save(Student theStudent);

    void remove(int id);

}
