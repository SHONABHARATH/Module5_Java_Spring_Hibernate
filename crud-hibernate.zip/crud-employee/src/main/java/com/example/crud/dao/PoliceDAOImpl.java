package com.example.crud.dao;

import com.example.crud.entity.Police;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class PoliceDAOImpl implements PoliceDAO{

    public EntityManager entityManager;

    public PoliceDAOImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public List<Police> findAll() {
        TypedQuery<Police> query = entityManager.createQuery("from Police",Police.class);
        List<Police> temp = query.getResultList();
        return temp;
    }

    @Override
    public Police findbyid(int id) {
        Police temp = entityManager.find(Police.class,id);
        return temp;
    }

    @Override
    public Police save(Police police) {
        Police temp = entityManager.merge(police);
        return temp;
    }

    @Override
    public void remove(int id) {
        Police temp = entityManager.find(Police.class,id);
        entityManager.remove(temp);
    }
}
