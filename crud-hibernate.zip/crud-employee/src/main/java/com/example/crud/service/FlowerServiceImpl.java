package com.example.crud.service;

import com.example.crud.dao.FlowerDAO;
import com.example.crud.entity.Flower;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class FlowerServiceImpl implements FlowerService{

    public FlowerDAO flowerdao;

    public FlowerServiceImpl(FlowerDAO myflowerdao)
    {
        flowerdao = myflowerdao;
    }

    @Override
    public List<Flower> findAll() {
        return flowerdao.findAll();
    }

    @Override
    public Flower findbyId(int id) {
        return flowerdao.findbyId(id);
    }
    @Transactional
    @Override
    public Flower save(Flower theflower) {
        return flowerdao.save(theflower);
    }
    @Transactional
    @Override
    public void remove(int id) {
            flowerdao.remove(id);
    }
}
