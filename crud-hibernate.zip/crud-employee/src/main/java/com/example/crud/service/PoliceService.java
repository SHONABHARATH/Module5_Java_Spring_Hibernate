package com.example.crud.service;

import com.example.crud.entity.Police;

import java.util.List;

public interface PoliceService {
    List<Police> findAll();

    Police findbyid(int id);

    Police save(Police police);

    void remove(int id);
}
