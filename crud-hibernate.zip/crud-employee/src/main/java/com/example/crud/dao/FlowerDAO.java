package com.example.crud.dao;

import com.example.crud.entity.Flower;

import java.util.List;

public interface FlowerDAO {

    List<Flower> findAll();
    Flower findbyId(int id);
    Flower save(Flower theflower);
    void remove(int id);

}
