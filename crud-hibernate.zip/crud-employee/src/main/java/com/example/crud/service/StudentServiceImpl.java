package com.example.crud.service;

import com.example.crud.dao.StudentDAO;
import com.example.crud.entity.Student;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
public class StudentServiceImpl implements StudentService{

    private StudentDAO studentDAO;

    public StudentServiceImpl(StudentDAO myStudentDAO)
    {
        studentDAO = myStudentDAO;
    }

    @Override
    public List<Student> findAll() {
        return studentDAO.findAll();
    }

    @Override
    public Student findbyId(int id) {
        return studentDAO.findbyId(id);
    }

    @Transactional
    @Override
    public Student save(Student theStudent) {
        return studentDAO.save(theStudent);
    }

    @Transactional
    @Override
    public void remove(int id) {
        studentDAO.remove(id);
    }
}
