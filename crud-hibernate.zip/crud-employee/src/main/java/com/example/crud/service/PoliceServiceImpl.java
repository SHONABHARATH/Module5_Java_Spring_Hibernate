package com.example.crud.service;

import com.example.crud.dao.PoliceDAO;
import com.example.crud.entity.Police;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class PoliceServiceImpl implements PoliceService{

    public PoliceDAO policeDAO;

    public PoliceServiceImpl(PoliceDAO thepolicedao)
    {
        policeDAO = thepolicedao;
    }

    @Override
    public List<Police> findAll() {
        return policeDAO.findAll();
    }

    @Override
    public Police findbyid(int id) {
        return policeDAO.findbyid(id);
    }

    @Transactional
    @Override
    public Police save(Police police) {
        return policeDAO.save(police);
    }

    @Transactional
    @Override
    public void remove(int id) {
        policeDAO.remove(id);
    }
}
