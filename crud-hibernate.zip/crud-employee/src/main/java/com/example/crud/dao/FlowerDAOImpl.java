package com.example.crud.dao;

import com.example.crud.entity.Flower;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public class FlowerDAOImpl implements FlowerDAO {
    public EntityManager entityManager;

    @Autowired
    public FlowerDAOImpl(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    @Override
    public List<Flower> findAll() {
        TypedQuery<Flower> query = entityManager.createQuery("from Flower",Flower.class);
        List<Flower> flower = query.getResultList();
        return flower;
    }

    @Override
    public Flower findbyId(int id) {
        Flower flower = entityManager.find(Flower.class,id);
        return flower;
    }

    @Override
    public Flower save(Flower theflower) {
        Flower flower = entityManager.merge(theflower);
        return flower;
    }

    @Override
    public void remove(int id) {
        Flower flower = entityManager.find(Flower.class,id);
        entityManager.remove(flower);
    }
}
