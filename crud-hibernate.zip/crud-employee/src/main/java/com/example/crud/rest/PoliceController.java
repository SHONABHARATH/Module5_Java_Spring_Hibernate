package com.example.crud.rest;

import com.example.crud.entity.Police;
import com.example.crud.service.PoliceService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class PoliceController {

    public PoliceService policeService;

    public PoliceController(PoliceService thepoliceservice)
    {
        policeService = thepoliceservice;
    }

    @GetMapping("/police")
    public List<Police> findall()
    {
        return policeService.findAll();
    }

    @GetMapping("/police/{id}")
    public Police findbyid(@PathVariable int id)
    {
        Police temp = policeService.findbyid(id);
        return temp;
    }
    
    @PostMapping("/police")
    public Police add(@RequestBody Police police){
        Police temp = policeService.save(police);
        return temp;
    }

    @PutMapping("/police")
    public Police update(@RequestBody Police police){
        Police temp = policeService.save(police);
        return temp;
    }

    @DeleteMapping("/police/{id}")
    public String deletebyid(@PathVariable int id)
    {
        Police temp = policeService.findbyid(id);
        policeService.remove(temp.getId());
        return "deleted id: "+ temp;
    }

    




}
