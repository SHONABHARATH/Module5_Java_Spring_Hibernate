package com.example.crud.service;


import com.example.crud.dao.StudentRepository;
import com.example.crud.entity.Student;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Optional;

@Service
public class StudentServiceImpl implements StudentService{

    private StudentRepository studentRepository;

    public StudentServiceImpl(StudentRepository myStudentRepository)
    {
        studentRepository = myStudentRepository;
    }

    @Override
    public List<Student> findAll() {
        return studentRepository.findAll();
    }

    @Override
    public Student findbyId(int id) {
        Optional<Student> byId = studentRepository.findById(id);
        Student temp = null;
        if (byId.isPresent())
        return temp;
        else
            throw new RuntimeException();
    }


    @Override
    public Student save(Student theStudent) {
        return studentRepository.save(theStudent);
    }


    @Override
    public void remove(int id) {
        studentRepository.deleteById(id);
    }
}
