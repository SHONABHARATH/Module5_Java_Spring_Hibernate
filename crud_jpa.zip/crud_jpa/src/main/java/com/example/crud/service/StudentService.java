package com.example.crud.service;

import com.example.crud.entity.Student;
import org.springframework.stereotype.Service;

import java.util.List;


public interface StudentService {

    List<Student> findAll();

    Student findbyId(int id);

    Student save(Student theStudent);

    void remove(int id);



}
