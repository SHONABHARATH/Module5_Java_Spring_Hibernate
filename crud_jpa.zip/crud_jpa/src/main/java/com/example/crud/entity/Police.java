package com.example.crud.entity;

import jakarta.persistence.*;

@Entity
@Table (name = "Police")
public class Police {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "name")
    private String name;

    @Column(name = "posting")
    private String posting;

    public Police(String name, String posting) {
        this.name = name;
        this.posting = posting;
    }

    @Override
    public String toString() {
        return "Police{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", posting='" + posting + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPosting() {
        return posting;
    }

    public void setPosting(String posting) {
        this.posting = posting;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Police()
    {

    }


}
