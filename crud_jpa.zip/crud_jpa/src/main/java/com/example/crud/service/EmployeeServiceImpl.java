package com.example.crud.service;


import com.example.crud.dao.EmployeeRepository;
import com.example.crud.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeServiceImpl implements EmployeeService{

    private EmployeeRepository employeeRepository;

    @Autowired
    public EmployeeServiceImpl(EmployeeRepository theemployeeRepository)
    {
        employeeRepository = theemployeeRepository;
    }

    @Override
    public List<Employee> findAll() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee findbyID(int theID) {
        Optional<Employee> id = employeeRepository.findById(theID);
        Employee temp=null;
        if (id.isPresent())
            temp=id.get();
        else
            throw new RuntimeException();
        return temp;
    }


    @Override
    public Employee save(Employee theEmployee) {
        return employeeRepository.save(theEmployee);
    }


    @Override
    public void remove(int theID) {
        employeeRepository.deleteById(theID);

    }
}
