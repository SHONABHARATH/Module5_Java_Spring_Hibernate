package com.example.crud.rest;


import com.example.crud.entity.Employee;
import com.example.crud.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import tools.jackson.databind.json.JsonMapper;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class EmployeeController {

    private final EmployeeService employeeservice;

@Autowired
    public EmployeeController(EmployeeService theemployeeService)
    {
        employeeservice = theemployeeService;

    }

    @GetMapping("/employees")
    public List<Employee> findAll()
    {
        return employeeservice.findAll();
    }

    @GetMapping("employees/{employeeID}")
    public Employee findbyID(@PathVariable int employeeID)
    {
        Employee theemployee = employeeservice.findbyID(employeeID);
        if(theemployee == null)
            throw new RuntimeException("Employee id not found");
        return theemployee;
    }

    @PostMapping("employees")
    public Employee addemployee(@RequestBody Employee theEmployee)
    {
    theEmployee.setId(0);
    Employee dbEmployee = employeeservice.save(theEmployee);
    return dbEmployee;
    }

    @PutMapping("employees")
    public Employee updateEmployee(@RequestBody Employee theEmployee)
    {
        Employee dbEmployee = employeeservice.save(theEmployee);
        return dbEmployee;
    }

    @DeleteMapping("/employees/{employeeID}")
    public String removeemployee(@PathVariable int employeeID)
    {
        Employee tempEmployee = employeeservice.findbyID(employeeID);
        if(tempEmployee==null)
            throw new RuntimeException("Employee not found "+employeeID);
         employeeservice.remove(employeeID);
         return "Employee id is deleted "+employeeID;
    }

//    @PatchMapping("employees/{employeeID}")
//    public Employee patchEmployee(@PathVariable int employeeID,
//                                  @RequestBody Map<String,Object> payload)
//    {
//        Employee tempEmployee = employeeservice.findbyID(employeeID);
//        if(tempEmployee==null)
//            throw new RuntimeException("Employee id not found");
//        if(payload.containsKey("id"))
//            throw new RuntimeException("json cannot have id"+employeeID);
//
//        Employee patchedEmployee = jsonMapper.updateValue(tempEmployee,payload);
//        Employee dbEmployee = employeeservice.save(patchedEmployee);
//        return dbEmployee;
//
//    }

}
