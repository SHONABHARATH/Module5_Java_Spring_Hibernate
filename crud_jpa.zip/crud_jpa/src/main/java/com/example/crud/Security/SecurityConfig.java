//package com.example.crud.Security;
//
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.authentication.jaas.memory.InMemoryConfiguration;
//import org.springframework.security.core.userdetails.User;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.provisioning.InMemoryUserDetailsManager;
//
//@Configuration
//public class SecurityConfig {
//
//
//    public InMemoryUserDetailsManager userDetailsManager(){
//        UserDetails John = User.builder()
//                .username("John")
//                .password("{noop}123")
//                .roles("EMPLOYEE")
//                .build();
//
//        UserDetails Mary = User.builder()
//                .username("Mary")
//                .password("{noop}123")
//                .roles("EMPLOYEE","MANAGER")
//                .build();
//
//        UserDetails Susan = User.builder()
//                .username("Susan")
//                .password("{noop}123")
//                .roles("EMPLOYEE","MANAGER","ADMIN")
//                .build();
//
//        return new InMemoryUserDetailsManager(John,Mary,Susan);
//    }
//}
