package com.example.crud.rest;

import com.example.crud.entity.Employee;
import com.example.crud.entity.Student;
import com.example.crud.service.StudentService;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")

public class StudentController {

    private StudentService studentService;

    public StudentController(StudentService thestudentservice)
    {
        studentService = thestudentservice;
    }

    @GetMapping("/students")
    public List<Student> getAll()
    {
        return studentService.findAll();
    }

    @GetMapping("/students/{sid}")
    public Student getid(@PathVariable int sid)
    {
        Student thestudent = studentService.findbyId(sid);
        return thestudent;
    }

    @PostMapping("/students")
    public Student add(@RequestBody Student theStudent)
    {
        Student student = studentService.save(theStudent);
        return student;
    }

    @PutMapping("/students")
    public Student update(@RequestBody Student theStudent)
    {
        Student student = studentService.save(theStudent);
        return student;
    }

    @DeleteMapping("/students/{id}")
    public String remove(@PathVariable int id)
    {
     //   Student student = studentService.findbyId(id);
        studentService.remove(id);
        return "Employee id is deleted "+id;
    }




}
